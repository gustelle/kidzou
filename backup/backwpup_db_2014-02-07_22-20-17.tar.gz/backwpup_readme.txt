You may have noticed the manifest.json file in this archive.
manifest.json might be needed for later restoring a backup from this archive.
Please leave manifest.json untouched and in place. Otherwise it is safe to be ignored.
