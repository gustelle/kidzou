Vous avez noté la présence du manifeste .json dans la sauvegarde.
le manifeste .json peut être nécessaire pour une restauration ultérieure de cette sauvegarde.
Merci de laisser le manifeste .json non modifié et à la même place. En d'autres termes, vous pouvez l'ignorer.
